<?php
include ('includes/login_check.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>
</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="stylesheet/main.css" rel="stylesheet" type="text/css">
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" background="images/Picture1.jpg">
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" class="border">
	<tr>
		<td colspan="2" align="center">  <table width="100%" border="0" cellspacing="0" cellpadding="0" >
			<tr>
				<td colspan="4" align="center"><?php include('includes/header.php') ; ?></td>
			</tr>
		</table></td>
	</tr>
	<tr>
		<td colspan="2" bgcolor="#FFFFFF" class="text12"><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
			<tr bgcolor="#F1F4F7">
				<td width="2%" rowspan="2" align="left" valign="top" class="justify"><table width="71%" border="0" cellspacing="0" cellpadding="0">
				</table></td>
				<td width="98%" align="left" valign="top" class="justify"></td>
			</tr>
			<tr bgcolor="#F1F4F7">
				<td height="216" width="100%" align="left" valign="top" class="justify"><table width="96%" border="0" align="left" cellpadding="0" cellspacing="0">
					<tr>
						<td height="60" align="left" style="font-size:15px"><strong>Acronyms</strong></td>
					</tr>
					<tr>
						<td align="left" style="font-size:13px">
						<p align="justify">CARA: Central Adoption Resource Agency</p>
						<p align="justify" style="font-size:15px">CMBS: Conditional Maternity Benefit Scheme</p>
						<p align="justify">CSS: Centrally Sponsored Scheme</p>
						<p align="justify">EAC: Externally Aided Component</p>
						<p align="justify">GC: General Component</p>
						<p align="justify">ICDS: Integrated Child Development Scheme</p>
						<p align="justify">ICPS: Integrated Child Protection Scheme</p>
						<p align="justify">ICTS: Information & Communication Technology in Schools</p>
						<p align="justify">IDMI: Infrastructure Development in Minority Institutions</p>
						<p align="justify">IEC: Information, Education and Communication</p>
						<p align="justify">IEDSS: Inclusicve Eduation for the Disabled at Secondary School</p>
						<p align="justify">KCH: Kalawatisaran Children�s Hospital</p>
						<p align="justify">KGBV: Kasturba Gandhi Balika Vidyalayas</p>
						<p align="justify">MDM: Mid-Day-Meal</p>
						<p align="justify">MHFW: Ministry of Health and Family Welfare</p>
						<p align="justify">MHRD: Ministry of Human Resource Development</p>
						<p align="justify">MLE: Ministry of Labour and Employment</p>
						<p align="justify">MMA: Ministry of Minority Affairs</p>
						<p align="justify">MSJE: Ministry of Social Justice and Employment</p>
						<p align="justify">MTA: Ministry of Tribal Affairs</p>
						<p align="justify">MWCD: Ministry of Women and Child Development</p>
						<p align="justify">MYAS: Ministry of Youth Affairs and Sports</p>
						<p align="justify">NCERT: National Council for Education Research and Training</p>
						<p align="justify">NCLP: National Child Labour Policy</p>
						<p align="justify">NCPCR: National Commission for Protection of Child Rights</p>
						<p align="justify">NCTE: National Council for Teacher Education</p>
						<p align="justify">NE: North East Areas</p>
						<p align="justify">NIOS: National Institution Open Schooling</p>
						<p align="justify">NIPCCD: National Institute of Public Cooperation & Child Development</p>
						<p align="justify">OBC: Other Backward Class</p>
						<p align="justify">PNDT: Pre-Natal Diagnostic Technology</p>
						<p align="justify">PPIP: Pulse Polio Immunisation Programme</p>
						<p align="justify">RCH: Reproductive Child Health</p>
						<p align="justify">RGSEAG: Rajiv Gandhi Scheme for Empowerment of Adolescent Girls (Sabla)</p>
						<p align="justify">RIP: Routine Immunisation Programme</p>
						<p align="justify">RMSA: Rashtriya Madyamik Shiksha Abhiyan</p>
						<p align="justify">SC: Scheduled Caste</p>
						<p align="justify">SCPSC: Special Component Plan for Schedule Castes</p>
						<p align="justify">SPQEM: Scheme for Providing Quality Education in Madarssas</p>
						<p align="justify">SSA: Sarva Shiksha Abhiyan</p>
						<p align="justify">ST: Scheduled Tribe</p>
						<p align="justify">STSP: Scheduled Tribe Sub Plan</p>
						<p align="justify">SUCCESS: Scheme for Universal Access & Quality at Secondary Stage</p>
						<p align="justify">UCD: Universal Children Day</p>
						<p align="justify">UT: Union Territories</p>
						</td>
					</tr>
					<tr>
						<td align="left">&nbsp;</td>
					</tr>
				</table></td>
				
			</tr>
			
		</table></td>
	</tr>
	<tr>
		<td height="1" colspan="2" bgcolor="#B4AF9D"></td>
	</tr>
	<tr>
		<td colspan="2"><table width="100%"  border="0" cellpadding="4" cellspacing="0">
			<tr bgcolor="#FFFFFF">
				<td ><table width="100%"  border="0" cellpadding="4" cellspacing="0">
					<tr>
						<td colspan="2" bgcolor="#FFFFFF" ></td>
					</tr>
					<tr>
						<td colspan="2" height="10" bgcolor="#FFFFFF" ></td>
					</tr>
					<tr  bgcolor="#FFFFFF" >
						<td align="left" height="20" ></td>
						<td align="right" ></td>
					</tr>
				</table></td>
			</tr>
		</table></td>
	</tr>
</table>
</body>
</head>
</html>
<a href="acronyms.php" class="back_menu" target="_blank">acronyms</a>