<?php
	session_start() ;
	include ('conn.php');
//	include ('forum_login_check.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<link href="stylesheet/css.css" type=text/css rel=stylesheet>
</head>

<body>
  <table width="800" border="0" align="center" cellpadding="0" cellspacing="0">
	<tr>
	  <td width="905" height="767" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
		<tr>
		  <td class="last_top_bg">&nbsp;</td>
		</tr>
		<tr>
		  <td height="228" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
			<tr>
			  <td width="10%" height="96" valign="top"></td>
			  <td width="80%" valign="top">
			    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="11" align="right"><img src="images/left_corner.gif" width="11" height="39" /></td>
                    <td height="39" background="images/top_bg.gif"><h1 align="center">Thanks for your payment</h1></td>
                    <td width="12"><img src="images/right_corner.gif" width="12" height="39" /></td>
                  </tr>
                  <tr>
                    <td rowspan="4" valign="bottom" background="images/left_bg.gif">&nbsp;</td>
                    <td height="10"></td>
                    <td rowspan="4" valign="bottom" background="images/right_bg.gif">&nbsp;</td>
                  </tr>
                  <tr>
                    <td height="10">&nbsp;</td>
                  </tr>
                  <tr>
                    <td><p><br><strong>The Health Clinic<br />
                      43 The Woods,
                            <br />
                          Rathdrum,
                          <br />
                          Co. Wicklow </strong></p>
                      </td>
                  </tr>
                  <tr>
                    <td height="125" align="right" class="text"></td>
                  </tr>
                  <tr>
                    <td></td>
                  </tr>
                  <tr>
                    <td valign="top" background="."><img src="images/left_bt_corner.gif" width="11" height="39" /></td>
                    <td background="images/bottom_bg.gif"></td>
                    <td valign="top"><img src="images/right_bt_corner.gif" width="12" height="39" /></td>
                  </tr>
                </table>
			  </td>
			  <td width="10%" valign="top"></td>
			</tr>
			<tr>
			  <td colspan="3" valign="top">&nbsp;</td>
			</tr>
		  </table></td>
		</tr>
	  </table>
	  </td>
	</tr>
  </table>
</body>
</html>