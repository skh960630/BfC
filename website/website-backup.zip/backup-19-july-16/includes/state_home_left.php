<table width="99%" border="0" cellpadding="0" cellspacing="0" bgcolor="#DDE4EC">
		<?php
			if($admin_level == 'super' or $admin_level == 'sub'){
		?>
     <tr>
        <td colspan="4" align="center" valign="top" bgcolor="#F1F3F8" height="5"></td>
        </tr>
      <tr>
        <td height="24" bgcolor="#DFE6EE">&nbsp;</td>
        <td height="24" colspan="3" bgcolor="#DFE6EE"><a href="main_state.php?page=entry"><strong>DATA ENTRY</strong></a></td>
        </tr>
      <tr>
        <td colspan="4" align="center" valign="top" bgcolor="#F1F3F8" height="5"></td>
        </tr>
<?php
}
?>      <tr>
        <td align="center" valign="top" bgcolor="#DFE6EE">&nbsp;</td>
        <td height="22" colspan="3" align="left" bgcolor="#DFE6EE"><a href="main_state.php?page=report"><strong>REPORTS</strong></a></td>
        </tr>
	  <tr>
        <td colspan="4" align="center" valign="top" bgcolor="#F1F3F8" height="150"></td>
        </tr>
    </table>
