<table width="99%" border="0" cellpadding="0" cellspacing="0" bgcolor="#DDE4EC">
      <tr>
        <td align="center" valign="top" bgcolor="#DFE6EE">&nbsp;</td>
        <td height="22" colspan="2" align="left" bgcolor="#DFE6EE"><strong>BUDGET REPORT</strong></td>
        </tr>
      <tr>
        <td colspan="3" align="center" valign="top" bgcolor="#F1F3F8" height="5"></td>
        </tr>
      <tr>
        <td width="10%" align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td width="7%" align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="union_budget.php" class="back_menu">Union Budget</a></td>
      </tr>
      <tr>
        <td width="10%" align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td width="7%" align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="state_budget.php" class="back_menu">State Budget</a></td>
      </tr>
      <tr>
        <td width="10%" align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td width="7%" align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="social_sector.php" class="back_menu">Social Sector (Union)</a></td>
      </tr>
      <tr>
        <td width="10%" align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td width="7%" align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="st_sector.php" class="back_menu">Social Sector (State)</a></td>
      </tr>
      <tr>
        <td width="10%" align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td width="7%" align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="head_report.php" class="back_menu">Head Report</a></td>
      </tr>
      <tr>
        <td width="10%" align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td width="7%" align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="head_report_search.php" class="back_menu">Expenditure Report Search</a></td>
      </tr>
      <tr>
        <td width="10%" align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td width="7%" align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="bfc_union.php" class="back_menu">BFC Report For Union</a></td>
      </tr>
      <tr>
        <td width="10%" align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td width="7%" align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="bfc_state.php" class="back_menu">BFC Report For State</a></td>
      </tr>
      <tr>
        <td colspan="3" align="center" valign="top" bgcolor="#F1F3F8" height="5"></td>
        </tr>
      <tr>
        <td height="24" bgcolor="#DFE6EE">&nbsp;</td>
        <td height="24" colspan="2" bgcolor="#DFE6EE"><strong>ADMIN MANAGEMENT</strong></td>
        </tr>
      <tr>
        <td colspan="3" align="center" valign="top" bgcolor="#F1F3F8" height="5"></td>
      </tr>
      <tr>
        <td align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="ministry.php" class="back_menu">Ministry</a></td>
      </tr>
      <tr>
        <td align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="sector.php" class="back_menu">Sector</a></td>
      </tr>
      <tr>
        <td align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="programme.php" class="back_menu">Programme</a></td>
      </tr>
      <tr>
        <td width="10%" align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td width="7%" align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td width="83%" bgcolor="#F1F3F8"><a href="department.php" class="back_menu">Department</a></td>
      </tr>
      <tr>
        <td align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="state.php" class="back_menu">State</a></td>
      </tr>
      <tr>
        <td align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="main_union.php" class="back_menu">Union Management</a></td>
      </tr>
      <tr>
        <td align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="main_state.php" class="back_menu">State Management</a></td>
      </tr>
      <tr>
        <td colspan="3" align="center" valign="top" bgcolor="#F1F3F8" height="5"></td>
        </tr>
	  <tr>
        <td colspan="3" align="center" valign="top" bgcolor="#F1F3F8" height="5"></td>
        </tr>
    </table>