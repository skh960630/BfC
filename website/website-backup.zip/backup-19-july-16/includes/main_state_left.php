<table width="99%" border="0" cellpadding="0" cellspacing="0" bgcolor="#DDE4EC">
<?php 
	if($_REQUEST['page']=="report"){
?>
      <tr>
        <td align="center" valign="top" bgcolor="#DFE6EE">&nbsp;</td>
        <td height="22" colspan="2" align="left" bgcolor="#DFE6EE"><strong>REPORTS</strong></td>
        </tr>
      <tr>
        <td colspan="3" align="center" valign="top" bgcolor="#F1F3F8" height="5"></td>
        </tr>
      <tr>
        <td width="10%" align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td width="7%"  align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="state_budget.php" class="back_menu">State Budget</a></td>
      </tr>
      <tr>
        <td width="10%" align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td width="7%"  align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="st_sector.php" class="back_menu">Social Sector</a></td>
      </tr>
      <tr>
        <td width="10%" align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td width="7%"  align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="st_head_report_search.php" class="back_menu">Expenditure Report Search</a></td>
      </tr>
      <tr>
        <td width="10%" align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td width="7%"  align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="bfc_state.php" class="back_menu">Budget for Children</a></td>
      </tr>
      <tr>
        <td colspan="3" align="center" valign="top" bgcolor="#F1F3F8" height="150"></td>
        </tr>
		<?php
}
	if($_REQUEST['page']=="entry"){
?>
      <tr>
        <td height="24" bgcolor="#DFE6EE">&nbsp;</td>
        <td height="24" colspan="2" bgcolor="#DFE6EE"><strong>DATA ENTRY</strong></td>
        </tr>
      <tr>
        <td colspan="3" align="center" valign="top" bgcolor="#F1F3F8" height="5"></td>
        </tr>
      <tr>
        <td align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="st_programme.php" class="back_menu">Programme</a></td>
      </tr>
      <tr>
        <td width="9%" align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td width="7%" align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td width="84%" bgcolor="#F1F3F8"><a href="st_department.php" class="back_menu">Department</a></td>
      </tr>
      <tr>
        <td align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="st_major_head.php?level=state" class="back_menu">Major Head</a></td>
      </tr>
      <tr>
        <td align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="st_sub_major_head.php?level=state" class="back_menu">Sub Major Head</a></td>
      </tr>
      <tr>
        <td align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="st_minor_head.php?level=state" class="back_menu">Minor Head</a></td>
      </tr>
      <tr>
        <td align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="st_gen_head.php?level=state" class="back_menu">General Head</a></td>
      </tr>
      <tr>
        <td align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="st_sub_head.php?level=state" class="back_menu">Sub Head</a></td>
      </tr>
      <tr>
        <td align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="st_detail_head.php?level=state" class="back_menu">Detail Head</a></td>
      </tr>
      <tr>
        <td align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="st_object_head.php?level=state" class="back_menu">Object Head</a></td>
      </tr>
      <tr>
        <td align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="st_other_head.php?level=state" class="back_menu">Other Head</a></td>
      </tr>
      <tr>
        <td align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="state_budget_entry.php" class="back_menu">State Budget</a></td>
      </tr>
      <tr>
        <td align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="st_sector_entry.php" class="back_menu">Social Sector</a></td>
      </tr>
      <!--tr>
        <td align="center" valign="top" bgcolor="#F1F3F8">&nbsp;</td>
        <td align="left" valign="top" bgcolor="#F1F3F8"><img src="images/arrow_backend.gif" width="5" height="9" vspace="8" /></td>
        <td bgcolor="#F1F3F8"><a href="acronyms.php" class="back_menu" target="_blank">Acronyms</a></td>
      </tr-->
      <tr>
        <td colspan="3" align="center" valign="top" bgcolor="#F1F3F8" height="50"></td>
        </tr>
		<?php
		}
		?>
	  <tr>
        <td colspan="3" align="center" valign="top" bgcolor="#F1F3F8" height="50"></td>
        </tr>
    </table>