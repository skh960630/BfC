<script language="JavaScript" src="javascript/gen_validatorv2.js" type="text/javascript"></script>
  <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#006699">
	<tr>
	  <td>&nbsp;</td>
	  <td>&nbsp;</td>
	</tr>
	<tr>
  	  <td width="20%" align="left"><img src="images/haq_logo.jpg" width="135" height="108" border="0" /></td>
	  <!--td width="20%" align="center"><img src="../../images/logo_clinic.gif" width="150" height="70" border="0"></td-->
	  <td width="80%" align="right" valign="top" class="head">Admin Panel</td>
	</tr>
	<tr>
	  <td colspan="2" >&nbsp;</td>
	</tr>
	<tr bgcolor="FFFFFF">
	  <td align="left">&nbsp;</td>
	  <td align="right" height="29" valign="middle" ></a> </td>
	</tr>
  </table>