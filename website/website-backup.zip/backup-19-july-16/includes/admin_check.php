<?php
if($admin_level=="sub"){
	die ("<center><h3>Access denied! Not a Autohorized User</h3></center><br>
			<div align='center' valign='top' height='10' ><a href='main.php' class='back_menu'>Click Here</a> to go to the Main Page.&nbsp;&nbsp;&nbsp;</div>
");
}
?>