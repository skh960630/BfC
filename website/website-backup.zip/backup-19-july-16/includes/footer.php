	  <table width="100%" bgcolor="#CCCCCC"  border="0" cellpadding="4" cellspacing="0">
	  	<tr>
		  <td colspan="2" ></td>
	    </tr>
	  	<tr>
		  <td colspan="2" height="10" ></td>
	  	</tr>
	  	<tr >
		  <td align="left" height="20" >HAQ Centre for Child Rights &copy;</td>
		  <td align="right" ></td>
	    </tr>
	  </table>          
