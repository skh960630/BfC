<?php
	include ('conn.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><html>
<head>
	<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="stylesheet/main.css"></head>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" background="images/Picture1.jpg">
	<table width="800" height="600" border="10" align="center" cellpadding="0" cellspacing="0" bgcolor="FFFFFF">
		<tr>
			<td colspan="2" align="center"></td>
		</tr>
		<tr>
			<td colspan="2" class="text12"><table width="800" height="600"  border="0" cellspacing="0" cellpadding="0" >
				<tr>
					<td align="center" valign="top" width="800" height="600"><img src="images/haqhome.jpg" width="800" height="600"  border="0" usemap="#login" />
					<map name="login">
					<area shape="rect" coords="682,35,770,79" href="index_1.php">
				  </map></td>
				</tr>
			</table></td>
		</tr>
	</table></td>
</body>
</html>
