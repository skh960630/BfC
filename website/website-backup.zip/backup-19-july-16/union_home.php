<?php
	include ('includes/login_check.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<title>
		</title>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		<link href="stylesheet/main.css" rel="stylesheet" type="text/css">
		<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" background="images/Picture1.jpg">
			<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" class="border">
				<tr>
					<td colspan="2" align="center">  <table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
	  <td colspan="4" align="center"><?php include('includes/header.php') ; ?></td>
	</tr>
  </table></td>
				</tr>
				<tr>
					<td colspan="2" bgcolor="#FFFFFF" class="text12"><table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" >
						<tr bgcolor="#F1F4F7">
							<td width="27%" rowspan="2" align="left" valign="top" class="justify"><table width="71%" border="0" cellspacing="0" cellpadding="0">
								<tr>
									<td bgcolor="#DFE6EE"><?php include ('includes/union_home_left.php')?></td>
								</tr>
							</table></td>
							<td width="39%" align="left" valign="top" class="justify"></td>
							<td width="34%" align="left" valign="top" class="justify"></td>
						</tr>
						<tr bgcolor="#F1F4F7">
							<td height="216" align="left" valign="top" class="justify"></td>
							<td align="right" valign="top" class="backheads"><a href="home.php" class="back_menu"><strong>Home Page</strong></a>&nbsp;&nbsp;&nbsp;</td>
						</tr>
					</table></td>
				</tr>
				<tr>
					<td height="1" colspan="2" bgcolor="#B4AF9D"></td>
				</tr>
				<tr>
					<td colspan="2"><table width="100%"  border="0" cellpadding="4" cellspacing="0">
						<tr bgcolor="#FFFFFF">
							<td ><table width="100%"  border="0" cellpadding="4" cellspacing="0">
								<tr>
									<td colspan="2" bgcolor="#FFFFFF" ></td>
								</tr>
								<tr>
									<td colspan="2" height="10" bgcolor="#FFFFFF" ></td>
								</tr>
								<tr  bgcolor="#FFFFFF" >
									<td align="left" height="20" ></td>
									<td align="right" ></td>
								</tr>
							</table></td>
						</tr>
					</table></td>
				</tr>
			</table>
		</body>
	</head>
</html>